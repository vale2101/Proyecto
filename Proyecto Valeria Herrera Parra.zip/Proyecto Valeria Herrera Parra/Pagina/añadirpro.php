<?php
include_once('./config/DatabaseProces.php');

$products = new DatabaseProcess();
$products->getAll();

?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
  <meta name="generator" content="Hugo 0.84.0">
  <title>Añadir producto</title>

  <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/checkout/">



  <!-- Bootstrap core CSS -->
  <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
  </style>


  <!-- Custom styles for this template -->
  <link href="form-validation.css" rel="stylesheet">
</head>

<body class="" style="background-color:#CFB98F;">

  <div class="container">

    <main>
      <div class="py-5 text-center">
        <img class="d-block mx-auto mb-4" src="La lupe (1).png" alt="" width="80" height="80">
        <h2>Añadir un producto</h2>
        <p class="lead">Debes proporcionar toda la informacion pedida a continuacion para poder añadir un nuevo producto</p>
      </div>
      <div class="row g-5">
        <div class="col-md-7 col-lg-8">
          <form action="" method="POST">
            <div class="row g-3">
            <div class="col-sm-6">
                <label for="firstName" class="form-label">Id</label>
                <input type="text" class="form-control" id="id" placeholder="" value="" required>
              </div>
              <div class="col-sm-6">
                <label for="firstName" class="form-label">Nombre del producto</label>
                <input type="text" class="form-control" id="nombre" placeholder="" value="" required>
              </div>
              <div class="col-sm-6">
                <label for="precio" class="form-label">Precio</label>
                <div class="input-group has-validation">
                  <input type="text" class="form-control" id="precio" placeholder="$----" required>
                </div>
              </div>
              <div class="col-12">
                <label for="username" class="form-label">Tipo</label>
                <div class="input-group has-validation">
                  <input type="text" class="form-control" id="tipo" placeholder="Maximo 1 parrafo" required>
                </div>
              </div>
              <div class="col-12">
                <label for="username" class="form-label">Descripcion</label>
                <div class="input-group has-validation">
                  <input type="text" class="form-control" id="descripcion" placeholder="" required>
                </div>
              </div>

              <hr class="my-4">

              <button class="w-100 btn btn-primary btn-lg" type="submit" >Añadir</button>
          </form>
        </div>
      </div>
    </main>

    <footer class="my-5 pt-5 text-muted text-center text-small">
      <p class="mb-1">&copy; 2023 La lupe restaurante tradicional Mexicano</p>
      <ul class="list-inline">
        <li class="list-inline-item"><a href="indexA.php">Pagina de inicio</a></li>
      </ul>
    </footer>
  </div>


  <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

  <script src="form-validation.js"></script>
</body>

</html>