<?php
include_once('./config/DatabaseProces.php');

$products = new DatabaseProcess();
$products->getAll();
$results = $products->getAll();
$products->getventas();
$ventas2 = $products->getventas();
$products->getclientes();
$clientes2 = $products->getclientes();
?>


<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
  <meta name="generator" content="Hugo 0.84.0">
  <title>Administrador</title>

  <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/grid/">



  <!-- Bootstrap core CSS -->
  <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }

    h2 {
      font-family: 'Courier New', Courier, monospace;
    }

    h1 {
      font-family: cursive;
    }

    h5 {
      font-family: Georgia, 'Times New Roman', Times, serif
    }
  </style>


  <!-- Custom styles for this template -->
  <link href="grid.css" rel="stylesheet">
</head>

<body class="py-4" style="background-color:#CFB98F;">

  <main>
    <div class="container">
      <center>
        <h1>Administrador</h1>
      </center>
      <center>
        <h5>Aca puedes listar, añadir, editar y eliminar las diferentes funciones</h5>
      </center>
      <br>
      <h2 class="mt-4"> <img src="La lupe (1).png" width="35" height="35" class="rounded-circle"> Productos </h2>
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-2 themed-grid-col"><strong>
              <center>Id</center>
            </strong></div>
          <div class="col-2 themed-grid-col"><strong>
              <center>Nombre</center>
            </strong></div>
          <div class="col-2 themed-grid-col"><strong>
              <center> Precio</center>
            </strong></div>
          <div class="col-2 themed-grid-col"><strong>
              <center>Tipo</center>
            </strong></div>
          <div class="col-2 themed-grid-col"><strong>
              <center>Descripcion</center>
            </strong></div>
        </div>

        <?php
        foreach ($results as $result) {
          echo "<div class='row mb-3'>
    
    <div class='col-sm-2 themed-grid-col'>" . $result->id . "</div>
    <div class='col-sm-2 themed-grid-col'>" . $result->nombre . "</div>
    <div class='col-sm-2 themed-grid-col'>" . $result->precio . "</div>
    <div class='col-sm-2 themed-grid-col'>" . $result->tipo . "</div>
    <div class='col-sm-2 themed-grid-col'>" . $result->descripcion . "</div>
    
    </div>";
        }
        ?>


        <footer class="text-muted py-5">
          <div class="container">
            <p class="float-end mb-1">
              <a class="w-60 btn btn-outline-secondary btn-lg" href="añadirpro.php">Añadir</a>
              <a class="w-60 btn btn-outline-secondary btn-lg" href="editarpro.php">Editar</a>
              <a class="w-60 btn btn-outline-secondary btn-lg" href="eliminarpro.php">Eliminar</a>
            </p>
          </div>
        </footer>
        <h2 class="mt-4"><img src="La lupe (1).png" width="35" height="35" class="rounded-circle"> Ventas</h2>
        <div class="row mb-2">
          <div class="col-2 themed-grid-col"><strong>
              <center>Id</center>
            </strong></div>
          <div class="col-2 themed-grid-col"><strong>
              <center>Producto</center>
            </strong></div>
          <div class="col-2 themed-grid-col"><strong>
              <center>Valor</center>
            </strong></div>
          <div class="col-2 themed-grid-col"><strong>
              <center>Cliente</center>
            </strong></div>
        </div>

        <?php
        foreach ($ventas2 as $ventas1) {
          echo "<div class='row mb-3'>
    
    <div class='col-sm-2 themed-grid-col'>" . $ventas1->id . "</div>
    <div class='col-sm-2 themed-grid-col'>" . $ventas1->productos . "</div>
    <div class='col-sm-2 themed-grid-col'>" . $ventas1->valor . "</div>
    <div class='col-sm-2 themed-grid-col'>" . $ventas1->cliente . "</div>
    
    </div>";
        }
        ?>


        <footer class="text-muted py-5">
          <div class="container">
            <p class="float-end mb-1">
              <a class="w-60 btn btn-outline-secondary btn-lg" href="editarventa.php">Editar</a>
              <a class="w-60 btn btn-outline-secondary btn-lg" href="añadirventa.php">Añadir</a>
              <a class="w-60 btn btn-outline-secondary btn-lg" href="eliminarventa.php">Eliminar</a>
            </p>
          </div>
        </footer>
        <h2 class="mt-4"><img src="La lupe (1).png" width="35" height="35" class="rounded-circle"> Clientes</h2>
        <div class="row mb-2">
          <div class="col-2 themed-grid-col"><strong>
              <center>ID</center>
            </strong></div>
          <div class="col-2 themed-grid-col"><strong>
              <center>Nombre</center>
            </strong></div>
          <div class="col-2 themed-grid-col"><strong>
              <center>Documento</center>
            </strong></div>
        </div>
        <?php
        foreach ($clientes2 as $clientes1) {
          echo "<div class='row mb-3'>
    
    <div class='col-sm-2 themed-grid-col'>" . $clientes1->id . "</div>
    <div class='col-sm-2 themed-grid-col'>" . $clientes1->nombre . "</div>
    <div class='col-sm-2 themed-grid-col'>" . $clientes1->documento . "</div>
    
    </div>";
        }
        ?>
        <footer class="text-muted py-5">
          <div class="container">
            <p class="float-end mb-1">
              <a class="w-60 btn btn-outline-secondary btn-lg" href="editarclien.php">Editar</a>
              <a class="w-60 btn btn-outline-secondary btn-lg" href="añadirclien.php">Añadir</a>
              <a class="w-60 btn btn-outline-secondary btn-lg" href="eliminarclien.php">Eliminar</a>
            </p>
          </div>
        </footer>
      </div>
</body>

</html>